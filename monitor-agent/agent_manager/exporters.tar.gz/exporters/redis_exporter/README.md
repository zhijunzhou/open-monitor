#start
#if no pwd:
./redis_exporter --redis.addr="redis://localhost:6379"
#if pwd:
./redis_exporter --redis.addr="redis://localhost:6379" --redis.password="prom_pwd"
