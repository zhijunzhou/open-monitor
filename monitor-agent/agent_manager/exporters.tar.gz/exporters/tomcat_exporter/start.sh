#!/bin/sh

nohup java -javaagent:{{abs_path}}/jmx_prometheus_javaagent-0.10.jar={{port}}:{{abs_path}}/config.yaml > /dev/null 2>&1 &
