#!/bin/sh

nohup {{abs_path}}/mysqld_exporter --config.my-cnf="my.cnf" --web.listen-address=":{{port}}" > data/app.log 2>&1 &
